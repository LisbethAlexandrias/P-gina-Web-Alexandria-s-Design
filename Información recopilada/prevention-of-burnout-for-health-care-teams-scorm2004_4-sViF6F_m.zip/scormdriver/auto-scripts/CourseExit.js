// version: 7.12.0.a.1.4.0
// sha: 0e5202cba19a8f313f9582767ec541bc709a1615
function niExit(){var o=window.parent;confirm("Are You Sure You Wish To Exit This Course?")&&o.ConcedeControl()}